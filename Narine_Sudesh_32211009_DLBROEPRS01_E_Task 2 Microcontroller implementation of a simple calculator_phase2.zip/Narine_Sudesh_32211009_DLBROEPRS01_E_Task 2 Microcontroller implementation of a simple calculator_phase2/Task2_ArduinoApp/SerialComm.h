// SerialComm.h
#ifndef SERIAL_COMM_H
#define SERIAL_COMM_H

#include <Arduino.h>

void initSerial(long baudRate);
bool isDataAvailable();
char readChar();  // Function to read a character from serial

#endif // SERIAL_COMM_H
