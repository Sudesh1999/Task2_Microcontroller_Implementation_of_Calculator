// SerialComm.cpp
#include "SerialComm.h"

void initSerial(long baudRate) {
    Serial.begin(baudRate);
    while (!Serial) {
        ; // Wait for serial port to connect. Necessary for native USB port only.
    }
}

bool isDataAvailable() {
    return Serial.available() > 0;
}

char readChar() {
    return Serial.read();  // Read a single character from serial
}
