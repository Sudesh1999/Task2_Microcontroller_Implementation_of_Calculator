// ExpressionParsing.h
#ifndef EXPRESSION_PARSING_H
#define EXPRESSION_PARSING_H

#include <Arduino.h>

bool parseExpression(const char* expr, float &operand1, float &operand2, char &op);

#endif // EXPRESSION_PARSING_H
