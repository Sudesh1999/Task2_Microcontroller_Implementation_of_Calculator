#include "ResultTransmission.h"

// Sends the computed result back to the PC via serial communication
void sendResult(float result) {
    // Start with a message for clarity
   // Serial.print("Computed Result: ");

    // Print the result to the serial monitor
    Serial.println(result, 2); // Printing the result with 2 decimal places for readability
}
