#include "ComputationModule.h"

// Computes the result of the expression based on the operands and the operator
bool computeResult(float operand1, float operand2, char operatorChar, float &result) {
    switch (operatorChar) {
        case '+':
            result = operand1 + operand2;
            break;
        case '-':
            result = operand1 - operand2;
            break;
        case '*':
            result = operand1 * operand2;
            break;
        case '/':
            if (operand2 == 0) {
                Serial.println("Error: Division by zero");
                return false;  // Avoid division by zero
            }
            result = operand1 / operand2;
            break;
        default:
            Serial.print("Error: Unknown operator '");
            Serial.print(operatorChar);
            Serial.println("'");
            return false;  // Unknown operator
    }
    return true;  // Computation successful
}
