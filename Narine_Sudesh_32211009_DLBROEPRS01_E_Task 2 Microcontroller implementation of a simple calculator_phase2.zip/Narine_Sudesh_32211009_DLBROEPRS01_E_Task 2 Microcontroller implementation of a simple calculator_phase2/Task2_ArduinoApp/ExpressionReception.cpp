// ExpressionReception.cpp
#include "ExpressionReception.h"
#include "SerialComm.h"  // Include the SerialComm header

bool receiveExpression(char *exprBuffer, unsigned int bufferSize) {
    unsigned int index = 0;  // Initialize index for buffer array

    while (isDataAvailable()) {  // Check if data is available
        char incomingChar = readChar();  // Use SerialComm function to read the char
        if (incomingChar == '\n' || incomingChar == '\r') {
            exprBuffer[index] = '\0';  // Null-terminate the string
            return true;  // Return true if full expression is received
        } else {
            if (index < bufferSize - 1) {  // Check buffer overflow
                exprBuffer[index++] = incomingChar;  // Store char in buffer
            }
        }
    }
    exprBuffer[index] = '\0';  // Ensure buffer is null-terminated
    return false;  // Return false if the expression is not yet complete
}
