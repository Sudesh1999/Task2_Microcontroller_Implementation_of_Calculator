#ifndef COMPUTATION_MODULE_H
#define COMPUTATION_MODULE_H

#include <Arduino.h>

// Function prototype for computing the result of the expression
bool computeResult(float operand1, float operand2, char operatorChar, float &result);

#endif
