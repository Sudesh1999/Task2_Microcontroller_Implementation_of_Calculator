#ifndef RESULT_TRANSMISSION_H
#define RESULT_TRANSMISSION_H

#include <Arduino.h>

void sendResult(float result);

#endif // RESULT_TRANSMISSION_H
