// ExpressionParsing.cpp
#include "ExpressionParsing.h"

bool parseExpression(const char* expr, float &operand1, float &operand2, char &op) {
    const char *p = expr;
    char numStr1[10] = {0};  // Buffer for first number
    char numStr2[10] = {0};  // Buffer for second number
    int i = 0;

    // Skip leading whitespace
    while (*p == ' ') p++;

    // Extract first operand
    while (*p >= '0' && *p <= '9' || *p == '.') {
        numStr1[i++] = *p++;
    }
    numStr1[i] = '\0'; // Null-terminate string
    operand1 = atof(numStr1);

    // Skip whitespace before operator
    while (*p == ' ') p++;
    op = *p++; // Assign operator

    // Skip whitespace after operator
    while (*p == ' ') p++;

    // Extract second operand
    i = 0;
    while (*p >= '0' && *p <= '9' || *p == '.') {
        numStr2[i++] = *p++;
    }
    numStr2[i] = '\0'; // Null-terminate string
    operand2 = atof(numStr2);

    // Validate the operator
    switch (op) {
        case '+':
        case '-':
        case '*':
        case '/':
            return true;  // Valid expression
        default:
            Serial.println("Error: Invalid operator");
            return false;  // Invalid operator
    }
}
