// ExpressionReception.h
#ifndef EXPRESSION_RECEPTION_H
#define EXPRESSION_RECEPTION_H

bool receiveExpression(char *exprBuffer, unsigned int bufferSize);

#endif // EXPRESSION_RECEPTION_H
