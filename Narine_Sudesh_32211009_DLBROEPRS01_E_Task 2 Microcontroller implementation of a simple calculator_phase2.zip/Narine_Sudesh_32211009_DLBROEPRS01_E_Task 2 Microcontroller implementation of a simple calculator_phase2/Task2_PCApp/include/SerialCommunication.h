#ifndef SERIALCOMMUNICATION_H
#define SERIALCOMMUNICATION_H

#include <string>
#include <windows.h>

class SerialCommunication {
public:
    SerialCommunication();
    ~SerialCommunication();
    bool initialize(const std::string& portName, int baudRate); // Updated function signature
    bool sendMessage(const std::string& message);
    std::string receiveMessage();
private:
    HANDLE hSerial;
};

#endif


