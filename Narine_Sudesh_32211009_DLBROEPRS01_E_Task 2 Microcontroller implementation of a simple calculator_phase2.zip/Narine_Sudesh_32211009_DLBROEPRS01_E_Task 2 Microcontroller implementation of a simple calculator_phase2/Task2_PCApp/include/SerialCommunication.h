#ifndef SERIALCOMMUNICATION_H
#define SERIALCOMMUNICATION_H

#include <string>
#include <windows.h>
//Class for serial communication with a serial port.
class SerialCommunication {
public:
    SerialCommunication();//constructor
    ~SerialCommunication();//destructor

    /**
     * Initializes the serial communication with the specified port and baud rate.
     *
     * param portName The name of the serial port (e.g., "COM1").
     * param baudRate The baud rate for communication.
     * return True if initialization is successful, false otherwise.
     */

    bool initialize(const std::string& portName, int baudRate);

    /**
     * Sends a message over the serial port.
     *
     * param message The message to send.
     * return True if the message is sent successfully, false otherwise.
     */

    bool sendMessage(const std::string& message);

    /**
     * Receives a message from the serial port.
     *
     * return The received message.
     */

    std::string receiveMessage();
private:
    HANDLE hSerial;
};

#endif


