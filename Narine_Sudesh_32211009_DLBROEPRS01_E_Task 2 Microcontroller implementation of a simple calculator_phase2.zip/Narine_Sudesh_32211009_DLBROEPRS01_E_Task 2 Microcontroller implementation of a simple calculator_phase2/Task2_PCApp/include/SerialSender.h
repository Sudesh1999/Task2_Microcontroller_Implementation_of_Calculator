#ifndef SERIALSENDER_H
#define SERIALSENDER_H

#include "SerialCommunication.h"
#include <string>

using namespace std;

class SerialSender {
public:
    SerialSender(SerialCommunication& serialComm); // Constructor
    bool sendExpression(const string& expression); // Function to send expression to Arduino

private:
    SerialCommunication& serialComm; // Reference to the serial communication object
};

#endif // SERIALSENDER_H


