#ifndef SERIALRECEIVER_H
#define SERIALRECEIVER_H

#include "SerialCommunication.h"
#include <string>

using namespace std;

class SerialReceiver {
//Class for receiving results from Arduino via serial communication.
public:
    SerialReceiver(SerialCommunication& serialComm); // Constructor
    string receiveResult(); // Function to receive result from Arduino and return it

private:
    SerialCommunication& serialComm; // Reference to the serial communication object
};

#endif // SERIALRECEIVER_H


