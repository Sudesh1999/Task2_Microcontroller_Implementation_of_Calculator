#ifndef USERINPUT_H
#define USERINPUT_H

#include <string>

using namespace std;

class UserInput {
public:
    string getExpression(); // Function to get algebraic expression from the user
};

#endif // USERINPUT_H


