#ifndef USERINPUT_H
#define USERINPUT_H

#include <string>

using namespace std;

class UserInput {
public:

    /**
     * Function to get an algebraic expression from the user.
     *
     * return The algebraic expression entered by the user.
     */

    string getExpression(); // Function to get algebraic expression from the user
};

#endif // USERINPUT_H


