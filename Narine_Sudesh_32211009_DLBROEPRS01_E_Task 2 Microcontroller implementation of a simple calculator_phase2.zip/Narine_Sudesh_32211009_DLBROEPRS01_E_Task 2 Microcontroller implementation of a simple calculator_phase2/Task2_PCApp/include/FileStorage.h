#ifndef FILESTORAGE_H
#define FILESTORAGE_H

#include <string>

using namespace std;

class FileStorage {
//Class for storing messages in a file.
public:
    FileStorage(const string& filename); // Constructor, param filename The name of the file to save messages
    void saveToFile(const string& message); // Function to save message to file, param message The message to save.

private:
    string filename; // Name of the file to save messages
};

#endif // FILESTORAGE_H


