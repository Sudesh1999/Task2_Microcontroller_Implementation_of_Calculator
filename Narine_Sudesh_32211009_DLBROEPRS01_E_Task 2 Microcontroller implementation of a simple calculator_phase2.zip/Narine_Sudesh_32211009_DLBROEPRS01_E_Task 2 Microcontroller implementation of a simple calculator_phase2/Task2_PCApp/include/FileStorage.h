#ifndef FILESTORAGE_H
#define FILESTORAGE_H

#include <string>

using namespace std;

class FileStorage {
public:
    FileStorage(const string& filename); // Constructor
    void saveToFile(const string& message); // Function to save message to file

private:
    string filename; // Name of the file to save messages
};

#endif // FILESTORAGE_H


