#include "SerialCommunication.h"
#include <iostream>
#include <windows.h>

using namespace std;

SerialCommunication::SerialCommunication() {
    hSerial = INVALID_HANDLE_VALUE;
}

SerialCommunication::~SerialCommunication() {
    if (hSerial != INVALID_HANDLE_VALUE) {
        CloseHandle(hSerial);
    }
}


bool SerialCommunication::initialize(const string& portName, int baudRate) {
    hSerial = CreateFile(portName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hSerial == INVALID_HANDLE_VALUE) {
        cerr << "Error: Unable to open serial port." << endl;
        return false;
    }

    DCB dcbSerialParams = {0};
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    if (!GetCommState(hSerial, &dcbSerialParams)) {
        cerr << "Error: Unable to get serial port state." << endl;
        CloseHandle(hSerial);
        return false;
    }
    dcbSerialParams.BaudRate = baudRate;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;
    if (!SetCommState(hSerial, &dcbSerialParams)) {
        cerr << "Error: Unable to set serial port state." << endl;
        CloseHandle(hSerial);
        return false;
    }

    return true;
}

bool SerialCommunication::sendMessage(const string& message) {
    DWORD bytesWritten;
    if (!WriteFile(hSerial, message.c_str(), message.length(), &bytesWritten, NULL)) {
        cerr << "Error: Unable to write to serial port." << endl;
        return false;
    }
    return true;
}

string SerialCommunication::receiveMessage() {
    const int bufferSize = 256;
    char buffer[bufferSize];
    DWORD bytesRead;
    if (!ReadFile(hSerial, buffer, bufferSize, &bytesRead, NULL)) {
        cerr << "Error: Unable to read from serial port." << endl;
        return "";
    }
    return string(buffer, bytesRead);
}
