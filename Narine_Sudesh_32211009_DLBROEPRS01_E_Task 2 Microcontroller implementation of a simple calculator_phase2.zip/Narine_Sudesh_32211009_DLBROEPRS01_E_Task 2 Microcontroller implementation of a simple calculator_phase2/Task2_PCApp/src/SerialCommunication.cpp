#include "SerialCommunication.h"
#include <iostream>
#include <windows.h>

using namespace std;

SerialCommunication::SerialCommunication() {
    hSerial = INVALID_HANDLE_VALUE;
}

SerialCommunication::~SerialCommunication() {
    if (hSerial != INVALID_HANDLE_VALUE) {
        CloseHandle(hSerial);
    }
}

/**
 * Initializes the serial communication with the specified port and baud rate.
 *
 * param portName The name of the serial port.
 * param baudRate The baud rate for communication.
 * return True if initialization is successful, false otherwise.
 */

bool SerialCommunication::initialize(const string& portName, int baudRate) {
    hSerial = CreateFile(portName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hSerial == INVALID_HANDLE_VALUE) {
        cerr << "Error: Unable to open serial port." << endl;
        return false;
    }

    DCB dcbSerialParams = {0};
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    if (!GetCommState(hSerial, &dcbSerialParams)) {
        cerr << "Error: Unable to get serial port state." << endl;
        CloseHandle(hSerial);
        return false;
    }
    dcbSerialParams.BaudRate = baudRate;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;
    if (!SetCommState(hSerial, &dcbSerialParams)) {
        cerr << "Error: Unable to set serial port state." << endl;
        CloseHandle(hSerial);
        return false;
    }

    return true;
}

/**
 * Sends a message over the serial port.
 *
 * param message The message to send.
 * return True if the message is sent successfully, false otherwise.
 */

bool SerialCommunication::sendMessage(const string& message) {
    DWORD bytesWritten;
    if (!WriteFile(hSerial, message.c_str(), message.length(), &bytesWritten, NULL)) {
        cerr << "Error: Unable to write to serial port." << endl;
        return false;
    }
    return true;
}

/**
 * Receives a message from the serial port.
 *
 * return The received message.
 */

string SerialCommunication::receiveMessage() {
    const int bufferSize = 256;
    char buffer[bufferSize];
    DWORD bytesRead;
    if (!ReadFile(hSerial, buffer, bufferSize, &bytesRead, NULL)) {
        cerr << "Error: Unable to read from serial port." << endl;
        return "";
    }
    return string(buffer, bytesRead);
}
