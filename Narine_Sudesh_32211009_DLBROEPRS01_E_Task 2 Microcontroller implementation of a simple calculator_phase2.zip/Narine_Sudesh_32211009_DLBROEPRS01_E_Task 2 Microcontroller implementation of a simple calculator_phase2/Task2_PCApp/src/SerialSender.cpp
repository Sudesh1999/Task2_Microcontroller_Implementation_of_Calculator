#include "SerialSender.h"
#include <iostream>

using namespace std;

SerialSender::SerialSender(SerialCommunication& serialComm) : serialComm(serialComm) {}

bool SerialSender::sendExpression(const string& expression) {
    // Send the expression to the Arduino
    if (!serialComm.sendMessage(expression)) {
        cerr << "Error: Unable to send expression to Arduino." << endl;
        return false;
    }
    return true;
}
