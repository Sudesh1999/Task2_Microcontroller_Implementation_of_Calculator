#include "FileStorage.h"
#include <iostream>
#include <fstream>

using namespace std;

FileStorage::FileStorage(const string& filename) : filename(filename) {}

void FileStorage::saveToFile(const string& message) {
    ofstream file(filename, ios::app); // Open file in append mode
    if (file.is_open()) {
        file << message << endl; // Write message to file
        file.close();
    } else {
        cerr << "Error: Unable to open file for saving." << endl;
    }
}
