#include "SerialReceiver.h"
#include <iostream>

using namespace std;

SerialReceiver::SerialReceiver(SerialCommunication& serialComm) : serialComm(serialComm) {}

string SerialReceiver::receiveResult() {
    // Receive the result from the Arduino
    string result = serialComm.receiveMessage();
    if (result.empty()) {
        cerr << "Error: Unable to receive result from Arduino." << endl;
    }
    return result;
}
