#include "UserInput.h"
#include <iostream>

using namespace std;

string UserInput::getExpression() {
    string expression;
    cout << "Enter algebraic expression: ";
    getline(cin, expression); // Accept the expression from the user
    expression += '\n'; // Append newline character to the end of the expression
    return expression;
}
