#include "UserInput.h"
#include <iostream>

using namespace std;

/**
 * Function to get an algebraic expression from the user.
 *
 * return The algebraic expression entered by the user.
 */

string UserInput::getExpression() {
    string expression;
    cout << "Enter algebraic expression: ";
    getline(cin, expression); // Accept the expression from the user
    expression += '\n'; // Append newline character to the end of the expression
    return expression;
}
