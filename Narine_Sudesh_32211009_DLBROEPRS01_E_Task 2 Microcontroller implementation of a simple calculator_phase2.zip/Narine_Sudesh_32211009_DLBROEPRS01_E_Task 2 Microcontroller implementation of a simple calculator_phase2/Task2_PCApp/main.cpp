#include <iostream>

#include "SerialCommunication.h"
#include "UserInput.h"
#include "SerialSender.h"
#include "SerialReceiver.h"
#include "FileStorage.h"

using namespace std;

/**
 * The main function.
 *
 * Initializes serial communication with the Arduino,
 * gets an algebraic expression from the user,
 * sends the expression to the Arduino,
 * receives the result from the Arduino,
 * logs the exchange in a text file,
 * and displays the result.
 *
 * return 0 on success, 1 on failure.
 */

int main() {
    // Initialize serial communication with the Arduino
    SerialCommunication serialComm;
    if (!serialComm.initialize("\\\\.\\COM3", 9600)) { // Adjust the port and baud rate accordingly
        cerr << "Error: Unable to initialize serial communication." << endl;
        return 1;
    }

    // Get algebraic expression from the user
    UserInput userInput;
    string expression = userInput.getExpression();

    // Send expression to the Arduino
    SerialSender serialSender(serialComm);
    if (!serialSender.sendExpression(expression)) {
        cerr << "Error: Unable to send expression to Arduino." << endl;
        return 1;
    }

    // Receive result from the Arduino
    SerialReceiver serialReceiver(serialComm);
    string result = serialReceiver.receiveResult();
    if (result.empty()) {
        cerr << "Error: Unable to receive result from Arduino." << endl;
        return 1;
    }

    // Log the exchange in a text file
    FileStorage fileStorage("message_exchange.txt");
    fileStorage.saveToFile("Expression: " + expression);
    fileStorage.saveToFile("Result: " + result);

    // Display the result
    cout << "Result: " << result << endl;

    return 0;
}
