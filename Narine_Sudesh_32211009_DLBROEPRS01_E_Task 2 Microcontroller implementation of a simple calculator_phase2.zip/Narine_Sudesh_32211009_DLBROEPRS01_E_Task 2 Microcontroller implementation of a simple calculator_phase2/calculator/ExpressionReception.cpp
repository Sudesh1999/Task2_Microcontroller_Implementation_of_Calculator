#include "ExpressionReception.h"
#include "SerialComm.h"  // Include the SerialComm header
/**
 * Receives an expression from the serial port.
 *
 * @param exprBuffer The buffer to store the received expression.
 * @param bufferSize The size of the buffer.
 * @return True if the full expression is received, false otherwise.
 */
bool receiveExpression(char *exprBuffer, unsigned int bufferSize) {
    unsigned int index = 0;  // Initialize index for buffer array
    // Loop until data is available on the serial port
    while (isDataAvailable()) {  // Check if data is available
        char incomingChar = readChar();  // Read a character from the serial port
        // Check if the received character is a newline or carriage return
        if (incomingChar == '\n' || incomingChar == '\r') {
            exprBuffer[index] = '\0';  // Null-terminate the string
            return true;  // Return true if full expression is received
        } else {
            if (index < bufferSize - 1) {  // Check buffer overflow
                exprBuffer[index++] = incomingChar;  // Store char in buffer
            }
        }
    }
    exprBuffer[index] = '\0';  // Ensure buffer is null-terminated
    return false;  // Return false if the expression is not yet complete
}
