#ifndef EXPRESSION_RECEPTION_H
#define EXPRESSION_RECEPTION_H
/**
 * Receives an expression from the serial port.
 *
 * @param exprBuffer The buffer to store the received expression.
 * @param bufferSize The size of the buffer.
 * @return True if the full expression is received, false otherwise.
 */
bool receiveExpression(char *exprBuffer, unsigned int bufferSize);

#endif // EXPRESSION_RECEPTION_H
