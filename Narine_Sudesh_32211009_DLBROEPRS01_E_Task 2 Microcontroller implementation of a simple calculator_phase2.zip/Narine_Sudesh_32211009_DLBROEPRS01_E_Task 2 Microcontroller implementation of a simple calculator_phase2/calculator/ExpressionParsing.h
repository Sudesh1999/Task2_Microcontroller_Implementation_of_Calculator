#ifndef EXPRESSION_PARSING_H
#define EXPRESSION_PARSING_H
/**
 * Parses an arithmetic expression into its operands and operator.
 *
 * @param expr The expression to parse.
 * @param operand1 Reference to store the first operand.
 * @param operand2 Reference to store the second operand.
 * @param op Reference to store the operator.
 * @return True if the expression is successfully parsed, false otherwise.
 */
#include <Arduino.h>

bool parseExpression(const char* expr, float &operand1, float &operand2, char &op);

#endif // EXPRESSION_PARSING_H
