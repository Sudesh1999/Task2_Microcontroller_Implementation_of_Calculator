#ifndef COMPUTATION_MODULE_H
#define COMPUTATION_MODULE_H
/**
 * Computes the result of the expression based on the operands and the operator.
 *
 * @param operand1 The first operand.
 * @param operand2 The second operand.
 * @param operatorChar The operator character (+, -, *, /).
 * @param result Reference to store the computed result.
 * @return True if computation is successful, false otherwise.
 */
#include <Arduino.h>

// Function prototype for computing the result of the expression
bool computeResult(float operand1, float operand2, char operatorChar, float &result);

#endif
