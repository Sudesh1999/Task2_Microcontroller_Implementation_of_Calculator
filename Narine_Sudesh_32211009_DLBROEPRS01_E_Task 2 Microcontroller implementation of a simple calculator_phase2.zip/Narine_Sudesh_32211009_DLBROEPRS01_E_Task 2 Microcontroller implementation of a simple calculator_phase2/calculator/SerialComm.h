#ifndef SERIAL_COMM_H
#define SERIAL_COMM_H

#include <Arduino.h>
/**
 * Initializes the serial communication with the specified baud rate.
 *
 * @param baudRate The baud rate at which to initialize the serial communication.
 */
void initSerial(long baudRate);
/**
 * Checks if data is available to read from the serial port.
 *
 * @return True if data is available, false otherwise.
 */
bool isDataAvailable();
/**
 * Reads a single character from the serial port.
 *
 * @return The character read from the serial port.
 */
char readChar();  // Function to read a character from serial

#endif // SERIAL_COMM_H
