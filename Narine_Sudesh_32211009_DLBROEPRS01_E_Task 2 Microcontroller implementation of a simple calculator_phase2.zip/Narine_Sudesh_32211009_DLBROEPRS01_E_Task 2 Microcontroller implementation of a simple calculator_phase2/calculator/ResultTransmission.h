//ResultTransmission.h
#ifndef RESULT_TRANSMISSION_H
#define RESULT_TRANSMISSION_H
/**
 * Sends the computed result back to the PC via serial communication.
 *
 * @param result The computed result to be sent.
 */
#include <Arduino.h>

void sendResult(float result);

#endif // RESULT_TRANSMISSION_H
