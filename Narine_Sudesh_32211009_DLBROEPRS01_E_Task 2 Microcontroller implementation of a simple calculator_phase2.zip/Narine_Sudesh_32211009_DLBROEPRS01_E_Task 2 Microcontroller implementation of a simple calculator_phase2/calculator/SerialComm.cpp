#include "SerialComm.h"
/**
 * Initializes the serial communication with the specified baud rate.
 *
 * @param baudRate The baud rate at which to initialize the serial communication.
 */
void initSerial(long baudRate) {
    Serial.begin(baudRate);
    while (!Serial) {
        ; // Wait for serial port to connect. Necessary for native USB port only.
    }
}
/**
 * Checks if data is available to read from the serial port.
 *
 * @return True if data is available, false otherwise.
 */
bool isDataAvailable() {
    return Serial.available() > 0;
}
/**
 * Reads a single character from the serial port.
 *
 * @return The character read from the serial port.
 */
char readChar() {
    return Serial.read();  // Read a single character from serial
}
